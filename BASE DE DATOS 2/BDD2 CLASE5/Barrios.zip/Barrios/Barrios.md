# Barrios Populares

1. Crear una carpeta llamada "Barrios Populares"
2. Dentro de esta carpeta, copiar el sqlite3.exe y el archivo barrios_populares.csv adjunto.
3. Abrir la consola cmd e ir a la carpeta creada en la paso 1.
4. Una vez dentro de la consola cmd, ejecutar:

```
sqlite> sqlite3 Barrios.db
```

Esto creará la base de datos Barrios.db donde importaremos el archivo csv.

5. Una vez dentro de la consola sqlite> Importamos el archivo csv:

```
sqlite> .mode csv
sqlite> .import barrios_populares.csv Base
```

Esto importara el archivo csv y se creará la tabla Base.\
Podemos ver s estructura con el siguiente comando: sqlite> .schema Base

```
  sqlite> .schema Base
   CREATE TABLE IF NOT EXISTS "Base"(
    "id_renabap" TEXT,
    "nombre_barrio" TEXT,
    "provincia" TEXT,
    "departamento" TEXT,
    "localidad" TEXT,
    "cantidad_viviendas_aproximadas" TEXT,
    "cantidad_familias_aproximada" TEXT,
    "decada_de_creacion" TEXT,
    "anio_de_creacion" TEXT,
    "energia_electrica" TEXT,
    "efluentes_cloacales" TEXT,
    "agua_corriente" TEXT,
    "cocina" TEXT,
    "calefaccion" TEXT,
    "titulo_propiedad" TEXT,
    "clasificacion_barrio" TEXT,
    "superficie_m2" TEXT);
```

- Nota: quizá la salida en cada una de las PCs sea distinta en formato,
  pero tendrá la misma estructura.

# Ejercitación:

1. Cuantos barrios hay por provincia?
2. Cuantos barrios hay por provincia y departamento?
3. Cuantos barrios hay por provincia, departamento y localidad?
4. Cuantos tipos distintos hay de:
   - Cocina
   - Calefaccion
   - Efluentes cloacales
   - Energia Electrica
5. Cual es el barrio mas viejo?
6. Cual es el barrio con mayor cantidad de viviendas?
7. Cual es el barrio con la mayor cantidad de familias?
8. Y el menor?
9. Cuantos barrios se crearon por década?
10. Cuantos barrios de crearon por año?
11. Cuantos barrios hay en total?
12. Hay barrios que estén mas de una vez?
